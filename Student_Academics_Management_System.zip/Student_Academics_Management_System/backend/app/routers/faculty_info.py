from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.schemas.faculty_info import FacultyCreate, FacultyOut, FacultyUpdate
from app.models.faculty_info import FacultyInfo
from app.models.user_credentials import UserCredentials
from app.database import get_db
from app.utils.hashing import pwd_context
from app.dependencies import get_current_active_user

router = APIRouter(prefix="/faculty", tags=["Faculty"])

# POST: Create Faculty (Admin only)
@router.post("/", response_model=FacultyOut, dependencies=[Depends(get_current_active_user("admin"))])
def create_faculty(faculty: FacultyCreate, db: Session = Depends(get_db)):
    existing_faculty = db.query(FacultyInfo).filter_by(faculty_id=faculty.faculty_id).first()
    if existing_faculty:
        raise HTTPException(status_code=400, detail="Faculty ID already exists")

    new_faculty = FacultyInfo(**faculty.dict())
    db.add(new_faculty)

    default_password = "faculty@123"
    hashed_password = pwd_context.hash(default_password)

    user = UserCredentials(
        user_id=new_faculty.faculty_id,
        role="faculty",
        password=hashed_password
    )

    db.add(user)
    db.commit()
    db.refresh(new_faculty)
    return new_faculty

# GET: All faculty (Admin only)
@router.get("/", response_model=list[FacultyOut], dependencies=[Depends(get_current_active_user("admin"))])
def get_all_faculty(db: Session = Depends(get_db)):
    return db.query(FacultyInfo).all()

# GET: Single faculty (Admin only)
@router.get("/{faculty_id}", response_model=FacultyOut, dependencies=[Depends(get_current_active_user("admin"))])
def get_faculty(faculty_id: str, db: Session = Depends(get_db)):
    faculty = db.query(FacultyInfo).filter_by(faculty_id=faculty_id).first()
    if not faculty:
        raise HTTPException(status_code=404, detail="Faculty not found")
    return faculty

# PUT: Update faculty (Admin only)
@router.put("/{faculty_id}", response_model=FacultyOut, dependencies=[Depends(get_current_active_user("admin"))])
def update_faculty(faculty_id: str, updated_data: FacultyUpdate, db: Session = Depends(get_db)):
    faculty = db.query(FacultyInfo).filter_by(faculty_id=faculty_id).first()
    if not faculty:
        raise HTTPException(status_code=404, detail="Faculty not found")

    for field, value in updated_data.dict(exclude_unset=True).items():
        setattr(faculty, field, value)

    db.commit()
    db.refresh(faculty)
    return faculty

# DELETE: Faculty + credentials (Admin only)
@router.delete("/{faculty_id}", dependencies=[Depends(get_current_active_user("admin"))])
def delete_faculty(faculty_id: str, db: Session = Depends(get_db)):
    faculty = db.query(FacultyInfo).filter_by(faculty_id=faculty_id).first()
    if not faculty:
        raise HTTPException(status_code=404, detail="Faculty not found")

    db.query(UserCredentials).filter_by(user_id=faculty_id).delete()
    db.delete(faculty)
    db.commit()
    return {"detail": "Faculty deleted successfully"}
