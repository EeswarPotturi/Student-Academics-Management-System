from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.database import get_db
from app.models.user_credentials import UserCredentials
from app.core import security

router = APIRouter(prefix="/auth", tags=["Authentication"])

class LoginRequest(BaseModel):
    user_id: str
    password: str

@router.post("/login")
def login(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(UserCredentials).filter(UserCredentials.user_id == request.user_id).first()

    if not user or not security.verify_password(request.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, 
            detail="Invalid credentials"
        )

    access_token = security.create_access_token(
        data={"sub": user.user_id, "role": user.role}
    )
    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/create-test-user")
def create_test_user(db: Session = Depends(get_db)):
    from app.core import security
    from app.models.user_credentials import UserCredentials

    existing = db.query(UserCredentials).filter(UserCredentials.user_id == "10001").first()
    if existing:
        return {"message": "Test user already exists"}

    hashed_password = security.get_password_hash("Admin@123")

    new_user = UserCredentials(
        user_id="10001",
        password=hashed_password,
        role="admin"
    )

    db.add(new_user)
    db.commit()
    return {"message": "✅ Test user created: 10001 / Admin@123"}
