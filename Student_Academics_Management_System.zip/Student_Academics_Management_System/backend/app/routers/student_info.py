from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.schemas.student_info import StudentCreate, StudentOut, StudentUpdate
from app.models.student_info import StudentInfo
from app.models.user_credentials import UserCredentials
from app.database import get_db
from app.utils.hashing import pwd_context
from app.dependencies import get_current_active_user

router = APIRouter(prefix="/student", tags=["Student"])

# POST: Create Student (Admin only)
@router.post("/", response_model=StudentOut, dependencies=[Depends(get_current_active_user("admin"))])
def create_student(student: StudentCreate, db: Session = Depends(get_db)):
    existing_student = db.query(StudentInfo).filter_by(student_id=student.student_id).first()
    if existing_student:
        raise HTTPException(status_code=400, detail="Student ID already exists")

    new_student = StudentInfo(**student.dict())
    db.add(new_student)

    default_password = "student@123"
    hashed_password = pwd_context.hash(default_password)

    user = UserCredentials(
        user_id=new_student.student_id,
        role="student",
        password=hashed_password
    )
    db.add(user)

    db.commit()
    db.refresh(new_student)
    return new_student

# GET all students (Admin only)
@router.get("/", response_model=list[StudentOut], dependencies=[Depends(get_current_active_user("admin"))])
def get_all_students(db: Session = Depends(get_db)):
    return db.query(StudentInfo).all()

# GET single student by ID (Admin only)
@router.get("/{student_id}", response_model=StudentOut, dependencies=[Depends(get_current_active_user("admin"))])
def get_student(student_id: str, db: Session = Depends(get_db)):
    student = db.query(StudentInfo).filter_by(student_id=student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    return student

# PUT update student info (Admin only)
@router.put("/{student_id}", response_model=StudentOut, dependencies=[Depends(get_current_active_user("admin"))])
def update_student(student_id: str, updated_data: StudentUpdate, db: Session = Depends(get_db)):
    student = db.query(StudentInfo).filter_by(student_id=student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    for field, value in updated_data.dict(exclude_unset=True).items():
        setattr(student, field, value)

    db.commit()
    db.refresh(student)
    return student

# DELETE student (Admin only)
@router.delete("/{student_id}", dependencies=[Depends(get_current_active_user("admin"))])
def delete_student(student_id: str, db: Session = Depends(get_db)):
    student = db.query(StudentInfo).filter_by(student_id=student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    # Remove credentials too
    db.query(UserCredentials).filter_by(user_id=student_id).delete()
    db.delete(student)
    db.commit()
    return {"detail": "Student deleted successfully"}
