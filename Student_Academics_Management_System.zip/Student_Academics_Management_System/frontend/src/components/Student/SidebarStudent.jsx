// src/components/Student/SidebarStudent.jsx
import "../../styles/dashboard-student.css";

export default function SidebarStudent({ setComponent }) {
  const items = [
    ["My Attendance", "attendance"],
    ["My Marks", "marks"],
    ["My CGPA", "cgpa"],
  ];

  return (
    <div className="sidebar-student">
      <h2>Student Portal</h2>
      <nav>
        <ul>
          {items.map(([label, key]) => (
            <li key={key}>
              <button onClick={() => setComponent(key)}>{label}</button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
