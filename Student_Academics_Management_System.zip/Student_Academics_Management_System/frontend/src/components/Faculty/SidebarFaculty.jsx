// src/components/Faculty/SidebarFaculty.jsx
import "../../styles/dashboard-faculty.css";

export default function SidebarFaculty({ setComponent }) {
  const items = [
    ["Attendance Records", "attendance"],
    ["Marks Records", "marks"],
    ["My Profile", "profile"],
  ];

  return (
    <div className="sidebar-faculty">
      <h2>Faculty Panel</h2>
      <nav>
        <ul>
          {items.map(([label, key]) => (
            <li key={key}>
              <button onClick={() => setComponent(key)}>{label}</button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
