import "../../styles/sidebar-admin.css";

export default function SidebarAdmin({ setComponent }) {
  const items = [
    ["Students", "studentInfo"],
    ["Faculty", "facultyInfo"],
    ["Admins", "adminInfo"],
    ["Sections", "section"],
    ["Courses", "courseCatalog"],
    ["Student–Course Map", "studentCourseMap"],
    ["Faculty–Course Map", "facultyCourseMap"],
    ["Section–Course Map", "sectionCourseMap"],
    ["Marks (Delete only)", "marks"],
    ["Attendance (Delete only)", "attendance"],
    ["Email Alert", "emailAlert"],
    ["User Credentials", "userCredentials"],
  ];

  return (
    <div className="sidebar-admin">
      <h2>Admin Panel</h2>
      <nav>
        <ul>
          {items.map(([label, key]) => (
            <li key={key}>
              <button onClick={() => setComponent(key)}>{label}</button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
