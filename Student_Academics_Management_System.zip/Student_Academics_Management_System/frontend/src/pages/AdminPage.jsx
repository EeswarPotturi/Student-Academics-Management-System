import AdminDashboard from "../components/Admin/AdminDashboard"; // ✅ correct casing

const AdminPage = () => {
  return (
    <div>
      <AdminDashboard />
    </div>
  );
};

export default AdminPage;
